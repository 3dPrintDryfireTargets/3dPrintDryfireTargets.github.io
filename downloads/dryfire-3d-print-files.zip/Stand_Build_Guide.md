# Modular PVC Dry Fire Target Stand

## Simple Build Guide

While not required to make use of the targets, this guide explains how to build a low-cost,
modular stand using PVC and galvanized tie plates.\

---

## Materials (creates two approx. 5 ft. tall stands with some material left over)

- 10 ft. x 1" Schedule 40 PVC pipe\

- 10 ft. x 3/4" Schedule 40 PVC pipe\

- (2) 1" PVC 3-way side outlet elbow\

- (2) 1" → 3/4" PVC reducer\

- (4) TP 3-1/8" x 7" 20-gauge galvanized tie plates\

- (4) 2" long 6-32 machine bolts\

- (4) 6-32 nuts

---

## Tools Required

- Drill\
- 0.18"--0.20" drill bit\
- Hacksaw or PVC cutter\
- Measuring tape\
- Marker

---

## Cut List

### 1" PVC

- (4) pieces -- 12 inches (legs)

- (2) pieces -- 36 inches (base vertical)

### 3/4" PVC

- (2) piece -- 24 inches (target mount)

---

## Step 1 -- Assemble the Base

1.  Insert the two 12" pieces into two openings of the 3-way elbow.
2.  Insert the 36" piece into the remaining opening.
3.  Install the 1" → 3/4" reducer on top of the 36" pipe.

This completes the stand base.

---

## Step 2 -- Drill the Target Mount

1.  Hold a tie plate horizontally.
2.  Locate a column of **4 holes**.
3.  Mark the top and bottom holes of that column on the 3/4" pipe.
4.  Drill straight through the pipe at both marks.

This spacing allows long horizontal, long vertical, or cross plate configurations.

---

## Step 3 -- Attach Tie Plates

1.  Align the tie plates with the drilled holes.
2.  Insert two of the 2" 6-32 bolts through plate and pipe.
3.  Secure with nuts to finger tight.

---

## Step 4 -- Final Assembly

Insert the 3/4" target mount into the reducer at the top of the stand.

Your stand is complete.

Break down for storage as needed - no glue is required.

---

## Notes

- Approximate cost: \~\$20 per stand (varies by region).
- If the stand attempts to fall backwards, add weight to the legs then cap them for more stability.

---

Have fun and stay safe. Share with a comrade who could also use a dry fire kit!
